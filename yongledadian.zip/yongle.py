from bs4 import BeautifulSoup
import json
import os
import requests
import time

# filename = 'read.yongledadian.com.cn.html'  # 网页的HTML文件名
# with open(filename, 'r', encoding='utf-8') as file:
#     html = file.read()
# soup = BeautifulSoup(html, 'html.parser') # 解析网页内容
# print(soup.find_all())
# http://read.yongledadian.com.cn/
# https://www.shidianguji.com/read?bookId=YLDD00000&chapterId=YLDD00000_1%2F1%2F4&source=PC&book_id=YLDD00000&version=1


# 使用requests库发送HTTP请求，获取网页内容
response = requests.get('https://www.shidianguji.com/read?bookId=YLDD00000&chapterId=YLDD00000_1%2F1%2F4&source=PC&book_id=YLDD00000&version=1')

# 获取当前脚本所在目录
dir_path = os.path.dirname(os.path.realpath(__file__))

# 创建文件保存路径
file_path = os.path.join(dir_path, 'example.txt')

# 将网页内容写入txt文件
with open(file_path, 'w', encoding='utf-8') as f:
    f.write(response.text)

# 输出文件保存路径
print('网页已保存为：{}'.format(file_path))
