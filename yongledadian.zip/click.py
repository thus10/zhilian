import os
import time

from bs4 import BeautifulSoup
from selenium import webdriver
from msedge.selenium_tools import Edge, EdgeOptions
from selenium.common.exceptions import StaleElementReferenceException



target = 'https://www.shidianguji.com/read?bookId=YLDD00000&chapterId=YLDD00000_1%2F1%2F4&source=PC&book_id=YLDD00000&version=1'# driver = webdriver.Edge()
options = EdgeOptions()
# options.binary_location = r'E:\edge\msedge.exe'	#这里添加edge的启动文件=>chrome的话添加chrome.exe的绝对路径
options.use_chromium = True
options.add_argument('headless')
driver = Edge(r'E:\edge\msedgedriver.exe',options=options)#这里添加的是driver的绝对路径
driver.get(target)



# # option.add_argument('headless')  # 设置option,后台运行
# # driver = webdriver.Chrome(chrome_options=option)
# driver.get(target)
# result1= driver.find_element_by_class_name('semi-tree-option semi-tree-option-level-2 semi-tree-option-collapsed')
# result1.click()
# result_list= driver.find_elements_by_class_name('fold')
# print(len(result_list))
# for i in range(0, len(result_list)):
#     result_list[i].click()
# result_list2= driver.find_elements_by_class_name('fold')
# print(len(result_list2))
# for i in range(0, len(result_list2)):
#     result_list2[i].click()

while True:
    try:
        result_list= driver.find_elements_by_class_name('fold')
        if len(result_list) == 0:
            break
        for i in range(0, len(result_list)):
            time.sleep(1)
            result_list[i].click()
    except StaleElementReferenceException:
        continue

selenium_page = driver.page_source
driver.quit()
soup = BeautifulSoup(selenium_page, 'html.parser')
# 获取当前脚本所在目录
dir_path = os.path.dirname(os.path.realpath(__file__))

# 创建文件保存路径
file_path = os.path.join(dir_path, 'element2.txt')

# 将BeautifulSoup元素写入txt文件
with open(file_path, 'w', encoding='utf-8') as f:
    for element in soup.find_all():
        f.write(str(element))

# 输出文件保存路径
print('网页元素已保存为：{}'.format(file_path))
