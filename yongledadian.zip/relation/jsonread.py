import json
filename = open('new_node.json', 'r',encoding='utf-8')
content = filename.read()
a = json.loads(content)
i=0
for item in a:
    i=i+1
    print(item)
print(i)
# filename = open('node.json', 'r',encoding='utf-8')
# content = filename.read()
# a = json.loads(content)
# seen = set()
# new_node = []
# for d in a:
#     t = tuple(d.items())
#     if t not in seen:
#         seen.add(t)
#         new_node.append(d)
# print(new_node)
# json_str = json.dumps(new_node)
# f2=open("new_node.json", 'a+', encoding='utf-8')
# f2.write(json_str)
# f2.close()