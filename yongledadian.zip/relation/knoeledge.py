import re
import time

# 假设文本文件名为 file.txt
# with open('yongle.txt', 'r', encoding='utf-8') as f:
#     lines = f.readlines()
#
# for line in lines:
#     # 通过正则表达式匹配三个层级文本元素
#     pattern = r'<div.*?class="semi-tree-option-level-1".*?>(.*?)<\/div>.*?<div.*?class="semi-tree-option-level-2".*?>(.*?)<\/div>.*?<div.*?class="semi-tree-option-level-3".*?>(.*?)<\/div>'
#     match = re.search(pattern, line)
#     if match:
#         # 输出三个层级文本元素
#         print(match.group(1), match.group(2), match.group(3))

# import re
#
# with open('element2.txt', 'r',encoding='utf-8') as f:
#     data = f.read()
#
# pattern = r'<div class="label"><a href=".*?">(.*?)</a></div>' \
#           r'<div class="label-no-ellipsis">(.*?)</div></div>' \
#           r'<div.*?><div.*?><a.*?>(.*?)</a></div><div.*?>(.*?)</div></div>' \
#           r'<div.*?><div.*?><a.*?>(.*?)</a></div><div.*?>(.*?)</div></div>'
#
# matches = re.findall(pattern, data)
#
# for match in matches:
#     level1, level1_desc, level2, level2_desc, level3, level3_desc = match
#     print(level1.strip(), level1_desc.strip(), level2.strip(), level2_desc.strip(), level3.strip(), level3_desc.strip())

from bs4 import BeautifulSoup
import json
f1 = open ("edge.csv",'a+',encoding='utf-8')
with open("element2.txt",encoding='utf-8') as f:
    html = f.read()

# 使用 BeautifulSoup 解析 HTML
soup = BeautifulSoup(html, 'html.parser')

# 使用 find_all() 方法找到所有的 label-no-ellipsis 元素
labels = soup.find_all(class_='label-no-ellipsis')
node=[]
jiedian = {}
jiedian['name'] = "永樂大典"
jiedian['url'] = "http://read.yongledadian.com.cn/"
jiedian['timestamp'] = int(time.strftime("%Y%m%d", time.localtime()))
node.append(jiedian)
tou=""
relation=""
wei=""
# 循环输出每个 label-no-ellipsis 元素的文本
for label in labels:
    print(label.text.strip())
    name=label.text.strip()
    if "永樂大典" in name:
        tou=""
        relation=""
        wei=""
        tou=name
        jiedian = {}
        jiedian['name'] = tou
        jiedian['url'] = "http://read.yongledadian.com.cn/"
        jiedian['timestamp'] = int(time.strftime("%Y%m%d", time.localtime()))
        node.append(jiedian)
        f1.write(f"{'永樂大典'},{'卷'},{tou}\n")
    elif len(name)<=2:
        relation=name
    else:
        wei=name
        jiedian = {}
        jiedian['name'] = wei
        jiedian['url'] = "http://read.yongledadian.com.cn/"
        jiedian['timestamp'] = int(time.strftime("%Y%m%d", time.localtime()))
        node.append(jiedian)
        f1.write(f"{tou},{relation},{wei}\n")

json_str = json.dumps(node)
f2=open("node.json", 'a+', encoding='utf-8')
f2.write(json_str)
f2.close()
f1.close()

