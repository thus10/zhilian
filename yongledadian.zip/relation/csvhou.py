import csv

# 打开原始CSV文件和新CSV文件
with open('edge.csv', 'r',encoding='utf-8') as input_file, open('new_edgetag.csv', 'w',encoding='utf-8', newline='') as output_file:
    reader = csv.reader(input_file)
    writer = csv.writer(output_file)

    unique_rows = []  # 用于存储不重复的行

    for row in reader:
        if row not in unique_rows:  # 如果行不存在于列表中，则将其添加
            unique_rows.append(row)
            print(row)
            print("1")

    for row in unique_rows:  # 将不重复的行写入新CSV文件
        writer.writerow(row)
        print(row)
        print("2")
