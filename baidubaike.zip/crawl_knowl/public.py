import threading
import requests
import time
import queue
from bs4 import BeautifulSoup
from urllib.parse import quote, unquote
import json
import network
import page_analysis_baidu
import page_analysis_wiki


# 多线程爬取one_batch_url
def multi_crawl(one_batch_url):
    '''
    :param list: name_list/url_list 一批待爬的列表
    :param name_url_tag: 'name'=>name_list, 'url'=>url_list
    :return: response队列
    '''

    # 从threading.Thread继承创建一个新的子类
    class myThread(threading.Thread):
        # 初始化，传入参数
        def __init__(self, url, q):
            '''
            :param q: 共享队列
            '''
            threading.Thread.__init__(self)
            self.url = url
            self.q = q

        # 线程需要运行的函数
        def run(self):
            # 爬取
            headers = {
                'Accept-Encoding': 'gzip, deflate, sdch',
                'Accept-Language': 'en-US,en;q=0.8',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Cache-Control': 'max-age=0',
                'Connection': 'keep-alive',
            }
            # 尝试爬取
            try:
                if self.url == 'https://baike.baidu.com/error.html':  # 证明词条无效
                    print('!!!!!!!!!crawl_error!!!!!!!!!!!!!')
                    return
                else:
                    response = requests.get(self.url, headers=headers)
                    # 获取线程锁
                    queueLock.acquire()
                    # 将(name,response)存入队列
                    self.q.put((self.url, response))
                    # 释放线程锁
                    queueLock.release()
            # 爬取失败
            except:
                print('========crawl_error========')
                return

    # 线程锁，用于对队列的异步操作
    queueLock = threading.Lock()
    # 队列，用于线程共享，队列中存取的为二元组，(name,response)
    htmlQueue = queue.Queue()
    # 线程池
    threads = []

    for url in one_batch_url:
        thread = myThread(url, htmlQueue)
        thread.start()
        threads.append(thread)

    for t in threads:
        t.join()
    return htmlQueue


def ana_batch(batch_url):
    # 一个批次爬取
    htmlQueue = multi_crawl(batch_url)
    # 一批次爬取到的所有结果
    batch_node = []
    batch_rel = []
    next_batch = []
    # 循环批量爬取结果，开始解析
    while not htmlQueue.empty():
        # url与对应的网页返回值
        (url, response) = htmlQueue.get()
        # url转换成中文
        ci_url = unquote(url)
        # 解析网页返回值
        html = response.content.decode('utf-8')
        # 获取词条名称
        ci_name = page_analysis_wiki.get_name_wiki(html)
        # 加入本条
        batch_node.append([ci_name, ci_url])

        # 提取内链
        contain_name_url_list = []
        contain_name_url_list = page_analysis_wiki.get_href_wiki(html, contain_name_url_list)

        # 生成所有节点和三元组
        for name_url in contain_name_url_list:
            batch_node.append(name_url)
            batch_rel.append([ci_name, ci_url, name_url[0], name_url[1]])
            next_batch.append(name_url[1])

    return batch_node, batch_rel, next_batch


def inter_href(href_dict):
    inter_set = list(href_dict.values())[0]
    for value in href_dict.values():
        inter_set = inter_set & value
    return inter_set


def union_href(href_dict):
    union_set = set()
    for value in href_dict.values():
        union_set = union_set | value
    return union_set
