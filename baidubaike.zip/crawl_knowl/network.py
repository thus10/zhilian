'''
本文件适用于拨号上网
断网和联网
'''
import time
import os
from bs4 import BeautifulSoup
import requests


# 连接网络
# name是网络名称。username是电话
def connect(name,username):
    password = "155740"
    cmd_str = "rasdial %s %s %s" % (name, username, password)
    res = os.system(cmd_str)
    if res == 0:
        print("connect successful")
    else:
        print('fail')
    time.sleep(5)
    return name


# 断网
def disconnect(name):
    cmdstr = "rasdial %s /disconnect" % name
    os.system(cmdstr)
    time.sleep(5)

#重连
def reconnect(name,username):
    disconnect(name)
    connect(name,username)


# 如果断网，重连
def juge_internet(url):
    headers = {
        'Accept-Encoding': 'gzip, deflate, sdch',
        'Accept-Language': 'en-US,en;q=0.8',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Cache-Control': 'max-age=0',
        'Connection': 'keep-alive',
    }
    try:
        response = requests.get(url, headers=headers)
        html = response.content.decode('utf-8')
        soup = BeautifulSoup(html, 'lxml')
        try:
            # 如果inter_2能找到，证明反爬了
            inter_2 = soup.findAll('1', {'2': '3'})[0]
            return False
        except:
            return True
    except:
        return False


if __name__ == '__main__':
    disconnect('宽带连接')
    connect('宽带连接','055194512565')