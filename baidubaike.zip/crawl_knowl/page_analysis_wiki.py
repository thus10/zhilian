'''
一个页面的分析
'''
import json
from bs4 import BeautifulSoup
import re
from selenium import webdriver
import time
from queue import Queue
import os
from urllib.parse import quote, unquote


# 去除文本中无用信息
def text_filter(element_tag):
    # 去引用标签
    inter_1 = element_tag.findAll('sup')
    if inter_1:
        for j in inter_1:
            j.decompose()
    # 去“编辑”标签
    inter_2 = element_tag.findAll('a', {'class': re.compile('.*edit-icon.*')})
    if inter_2:
        for j in inter_2:
            j.decompose()
    # 去“图片”标签
    inter_3 = element_tag.findAll('div', {'class': re.compile('.*lemma-picture.*')})
    if inter_3:
        for j in inter_3:
            j.decompose()
    # 去“故事名称”标签
    inter_4 = element_tag.findAll('span', {'class': 'title-prefix'})
    if inter_4:
        for j in inter_4:
            j.decompose()


def get_property(html, propertyDict):
    '''
    获取词条的属性值对
    :param html:
    :return:propertyDict，key为属性名，value为属性值
    '''

    soup = BeautifulSoup(html, 'lxml')
    inter_1 = soup.findAll('div', {'class': 'basic-info cmn-clearfix'})
    if inter_1:
        text_filter(inter_1[0])
        inter_2 = inter_1[0].findAll('dt', {'class': 'basicInfo-item name'})
        if inter_2:
            for i in inter_2:
                property_name = i.get_text(strip=True).replace('\xa0', '').replace(' ', '').replace(',', '，')  # 属性名
                property_value = i.next_sibling.next_sibling \
                    .get_text(strip=True).replace('\xa0', '').replace(' ', '').replace(',', '，')  # 属性值
                propertyDict[property_name] = property_value  # 保存
    return propertyDict


def get_abstract(html):
    '''
    获取词条的摘要
    :param html:
    :return: 摘要字符串
    '''
    abstract = ''
    soup = BeautifulSoup(html, 'lxml')
    inter_1 = soup.findAll('div', {'class': 'lemma-summary', 'label-module': 'lemmaSummary'})
    if inter_1:
        text_filter(inter_1[0])
        abstract = inter_1[0].get_text(strip=True).replace('\xa0', '').replace(' ', '') \
            .replace(',', '，').replace('\n', '').replace('\t', '')
    return abstract


# 提取链接信息
def get_href_wiki(html, contain_name_url_list):
    '''
    :param html:
    :param contain_name_url_set:
    :return:
    '''
    soup = BeautifulSoup(html, 'lxml')
    inter_1 = soup.findAll('div', {'id': 'bodyContent', 'class': 'vector-body'})
    for i in inter_1:
        text_filter(i)
        inter_2 = i.findAll('a', {'href': re.compile('.*/wiki/.*')})
        name = ""
        url = ""
        for j in inter_2:
            name = j.get_text(strip=True).replace('\xa0', '').replace(' ', '').replace(',', '，').replace('\n',
                                                                                                         '').replace(
                '\t', '')
            url = 'https://zh.wikipedia.org/' + unquote(j['href'])
            if name and url:
                contain_name_url_list.append([name, url])  # 加入姓名和链接
    return contain_name_url_list


def get_name_wiki(html):
    """
    获取词条名称
    :param html:
    :return: 名称字符串
    """
    soup = BeautifulSoup(html, 'lxml')
    inter_1 = soup.findAll('span', {'class': 'mw-page-title-main'})
    text_filter(inter_1[0])
    name = inter_1[0].get_text(strip=True)
    return name


# 获取同义词数组
def get_tongyi(html, contain_name_url_set, main_name):
    '''
    :param html:
    :param contain_name_url_set:
    :param main_name:
    :return:
    '''
    soup_1 = BeautifulSoup(html, 'lxml')
    inter_1 = soup_1.findAll('ul', {'class': 'polysemantList-wrapper cmn-clearfix'})
    if inter_1:
        text_filter(inter_1[0])
        soup_2 = BeautifulSoup(str(inter_1[0]), 'lxml')
        inter_2 = soup_2.findAll('a', href=re.compile("/item/"))  # 正则筛选
        for i in inter_2:
            tongyiURL = 'https://baike.baidu.com' + i.get('href')  # 加url头部
            tongyi_name = i.get_text(strip=True)
            contain_name_url_set.add((main_name + '（' + tongyi_name + '）', tongyiURL))  # 保存名称和url
    return contain_name_url_set


def get_rel(html, url, contain_name_url_set, rel_set):
    '''
    获取关系
    :param html:
    :return:
    '''
    soup_1 = BeautifulSoup(html, 'lxml')

    # 下面是第一种关系抽取规则（见孔子）
    inter_1 = soup_1.findAll('li', {'class': 'lemma-relation-item'})
    if inter_1:
        for i in inter_1:
            inter_2 = i.findAll('a', {'href': re.compile('.*/item/.*')})
            for j in inter_2:
                rel_people_url = 'https://baike.baidu.com' + j['href']  # 关系人物url
                inter_3 = j.findAll('span')
                if len(inter_3) == 2:  # 如果是关系（长度等于2）
                    rel_name = inter_3[0].get_text(strip=True).replace('\xa0', '').replace(' ', '').replace(',',
                                                                                                            '，').replace(
                        '\n', '').replace('\t', '')
                    rel_people_name = inter_3[1].get_text(strip=True).replace('\xa0', '').replace(' ', '').replace(',',
                                                                                                                   '，').replace(
                        '\n', '').replace('\t', '')

                    contain_name_url_set.add((rel_people_name, rel_people_url))  # 关系人物名称-链接存储
                    rel_set.add((url, rel_name, rel_people_url))  # 存入关系集合

    # 下面是第二种关系抽取规则（见杨幂）
    inter_4 = soup_1.findAll('div', {'id': 'slider_relations'})
    if inter_4:
        for i in inter_4:
            inter_5 = i.findAll('a', {'href': re.compile('.*/item/.*')})
            for j in inter_5:
                rel_people_url = 'https://baike.baidu.com' + j['href']  # 关系人物url
                inter_6 = j.findAll('em')
                if inter_6:
                    rel_people_name = inter_6[0].get_text(strip=True)  # 关系人物名称
                    inter_6[0].decompose()  # 去除这个标签
                    rel_name = j.get_text(strip=True).replace('\xa0', '').replace(' ', '').replace(',', '，').replace(
                        '\n', '').replace('\t', '')  # 关系名称

                    contain_name_url_set.add((rel_people_name, rel_people_url))  # 关系人物名称-链接存储
                    rel_set.add((url, rel_name, rel_people_url))  # 存入关系集合

    return contain_name_url_set, rel_set


# 词条属性对齐
def alignProperty(old_property_dict, set_tag):
    '''
    对齐人物属性
    :param dictPeople: 人物字典
    :param tag: 需要打的标签,如“baidubaike”
    :return: people对象
    '''

    fix_property_dict = old_property_dict
    fix_property_dict['ispublic'] = '10'
    fix_property_dict['sex'] = '不详'
    fix_property_dict['tag'] = set_tag
    # {
    #     'strID' = '-1',
    #     'numID' = '-1',
    #     name=''    # 中文名/姓名==姓名
    #     ispublic='10'
    #     zi=''    # 字
    #     used_name=''    # 别名（绰号）==曾用名
    #     sex='不详'    # 性别==性别
    #     birth=''    # 出生年月==出生日期
    #     death_date = ''    # 去世年月==过世日期
    #     era = ''    # 所处时代==朝代
    #     birthPlace = ''    # 出生地==出生地
    #     occupation =''    # 职业==职业
    #     education=''    # 文化程度==毕业院校
    #     description=''    # 其他描述
    #     abstract=''    # 简介
    #     mingzu=''    # 民族==民族
    #     guoji=''    # 国籍==国籍
    #     shihao=''    # 谥号==谥号
    #     lable=''    # 标签
    #     zhuzuo=''    # 代表作品==著作
    #     danwei=''    # 所属公司==工作单位
    #     jiguan=''    # 籍贯==籍贯
    #     english_name=''    # 英文名==英文名
    #     tag=set_tag

    # 当前人物的所有key
    peopleKeys = old_property_dict.keys()

    # 姓名
    if '姓名' in peopleKeys:
        fix_property_dict['name'] = old_property_dict['姓名'].replace('\xa0', '').replace(' ', '').replace(',',
                                                                                                           '，').strip()
    else:
        if '中文名' in peopleKeys:
            fix_property_dict['name'] = old_property_dict['中文名'].replace('\xa0', '').replace(' ', '').replace(',',
                                                                                                                 '，').strip()
        else:
            if '中文名称' in peopleKeys:
                fix_property_dict['name'] = old_property_dict['中文名称'].replace('\xa0', '').replace(' ', '').replace(
                    ',', '，').strip()
            else:
                if '名称' in peopleKeys:
                    fix_property_dict['name'] = old_property_dict['名称'].replace('\xa0', '').replace(' ', '').replace(
                        ',', '，').strip()
                else:
                    fix_property_dict['name'] = old_property_dict['strID'].split('（')[0].replace('\xa0', '').replace(
                        ' ', '').replace(',', '，').strip()

    if '字号' in peopleKeys:
        fix_property_dict['zi'] = old_property_dict['字号'].replace('\xa0', '').replace(' ', '').replace(',',
                                                                                                         '，').strip()

    if '别名' in peopleKeys:
        fix_property_dict['used_name'] = old_property_dict['别名'].replace('\xa0', '').replace(' ', '').replace(',',
                                                                                                                '，').strip()
    else:
        if '别名（绰号）' in peopleKeys:
            fix_property_dict['used_name'] = old_property_dict['别名（绰号）'].replace('\xa0', '').replace(' ',
                                                                                                         '').replace(
                ',', '，').strip()
        else:
            if '别称' in peopleKeys:
                fix_property_dict['used_name'] = old_property_dict['别称'].replace('\xa0', '').replace(' ', '').replace(
                    ',', '，').strip()
            else:
                if '中文别名' in peopleKeys:
                    fix_property_dict['used_name'] = old_property_dict['中文别名'].replace('\xa0', '').replace(' ',
                                                                                                               '').replace(
                        ',', '，').strip()

    if '性别' in peopleKeys:
        fix_property_dict['sex'] = old_property_dict['性别'].replace('\xa0', '').replace(' ', '').replace(',',
                                                                                                          '，').strip()

    if '出生年月' in peopleKeys:
        fix_property_dict['birth'] = old_property_dict['出生年月'].replace('\xa0', '').replace(' ', '').replace(',',
                                                                                                                '，').strip()
    else:
        if '出生日期' in peopleKeys:
            fix_property_dict['birth'] = old_property_dict['出生日期'].replace('\xa0', '').replace(' ', '').replace(',',
                                                                                                                    '，').strip()
        else:
            if '出生时间' in peopleKeys:
                fix_property_dict['birth'] = old_property_dict['出生时间'].replace('\xa0', '').replace(' ', '').replace(
                    ',', '，').strip()

    if '去世年月' in peopleKeys:
        fix_property_dict['death_date'] = old_property_dict['去世年月'].replace('\xa0', '').replace(' ', '').replace(
            ',', '，').strip()
    else:
        if '去世日期' in peopleKeys:
            fix_property_dict['death_date'] = old_property_dict['去世日期'].replace('\xa0', '').replace(' ',
                                                                                                        '').replace(',',
                                                                                                                    '，').strip()
        else:
            if '去世时间' in peopleKeys:
                fix_property_dict['death_date'] = old_property_dict['去世时间'].replace('\xa0', '').replace(' ',
                                                                                                            '').replace(
                    ',', '，').strip()

    if '所处时代' in peopleKeys:
        fix_property_dict['era'] = old_property_dict['所处时代'].replace('\xa0', '').replace(' ', '').replace(',',
                                                                                                              '，').strip()
    else:
        if '所处朝代' in peopleKeys:
            fix_property_dict['era'] = old_property_dict['所处朝代'].replace('\xa0', '').replace(' ', '').replace(',',
                                                                                                                  '，').strip()
        else:
            if '朝代' in peopleKeys:
                fix_property_dict['era'] = old_property_dict['朝代'].replace('\xa0', '').replace(' ', '').replace(',',
                                                                                                                  '，').strip()

    if '出生地' in peopleKeys:
        fix_property_dict['birthPlace'] = old_property_dict['出生地'].replace('\xa0', '').replace(' ', '').replace(',',
                                                                                                                   '，').strip()

    if '职业' in peopleKeys:
        fix_property_dict['occupation'] = old_property_dict['职业'].replace('\xa0', '').replace(' ', '').replace(',',
                                                                                                                 '，').strip()

    if '毕业院校' in peopleKeys:
        fix_property_dict['education'] = old_property_dict['毕业院校'].replace('\xa0', '').replace(' ', '').replace(',',
                                                                                                                    '，').strip()
    else:
        if '毕业学院' in peopleKeys:
            fix_property_dict['education'] = old_property_dict['毕业学院'].replace('\xa0', '').replace(' ', '').replace(
                ',', '，').strip()
        else:
            if '文化程度' in peopleKeys:
                fix_property_dict['education'] = old_property_dict['文化程度'].replace('\xa0', '').replace(' ',
                                                                                                           '').replace(
                    ',', '，').strip()

    if '民族' in peopleKeys:
        fix_property_dict['mingzu'] = old_property_dict['民族'].replace('\xa0', '').replace(' ', '').replace(',',
                                                                                                             '，').strip()

    if '国籍' in peopleKeys:
        fix_property_dict['guoji'] = old_property_dict['国籍'].replace('\xa0', '').replace(' ', '').replace(',',
                                                                                                            '，').strip()

    if '谥号' in peopleKeys:
        fix_property_dict['shihao'] = old_property_dict['谥号'].replace('\xa0', '').replace(' ', '').replace(',',
                                                                                                             '，').strip()

    if '代表作品' in peopleKeys:
        fix_property_dict['zhuzuo'] = old_property_dict['代表作品'].replace('\xa0', '').replace(' ', '').replace(',',
                                                                                                                 '，').strip()
    else:
        if '主要作品' in peopleKeys:
            fix_property_dict['zhuzuo'] = old_property_dict['主要作品'].replace('\xa0', '').replace(' ', '').replace(
                ',', '，').strip()
        else:
            if '相关著作' in peopleKeys:
                fix_property_dict['zhuzuo'] = old_property_dict['相关著作'].replace('\xa0', '').replace(' ',
                                                                                                        '').replace(',',
                                                                                                                    '，').strip()

    if '任职单位' in peopleKeys:
        fix_property_dict['danwei'] = old_property_dict['任职单位'].replace('\xa0', '').replace(' ', '').replace(',',
                                                                                                                 '，').strip()
    else:
        if '所属公司' in peopleKeys:
            fix_property_dict['danwei'] = old_property_dict['所属公司'].replace('\xa0', '').replace(' ', '').replace(
                ',', '，').strip()
        else:
            if '工作单位' in peopleKeys:
                fix_property_dict['danwei'] = old_property_dict['工作单位'].replace('\xa0', '').replace(' ',
                                                                                                        '').replace(',',
                                                                                                                    '，').strip()

    if '籍贯' in peopleKeys:
        fix_property_dict['jiguan'] = old_property_dict['籍贯'].replace('\xa0', '').replace(' ', '').replace(',',
                                                                                                             '，').strip()

    if '英文名' in peopleKeys:
        fix_property_dict['english_name'] = old_property_dict['英文名'].replace('\xa0', '').replace(' ', '').replace(
            ',', '，').strip()
    else:
        if '外文名' in peopleKeys:
            fix_property_dict['english_name'] = old_property_dict['外文名'].replace('\xa0', '').replace(' ',
                                                                                                        '').replace(',',
                                                                                                                    '，').strip()
        else:
            if '英文全名' in peopleKeys:
                fix_property_dict['english_name'] = old_property_dict['英文全名'].replace('\xa0', '').replace(' ',
                                                                                                              '').replace(
                    ',', '，').strip()
            else:
                if '外文名称' in peopleKeys:
                    fix_property_dict['english_name'] = old_property_dict['外文名称'].replace('\xa0', '').replace(' ',
                                                                                                                  '').replace(
                        ',', '，').strip()

    return fix_property_dict


# 通过网页返回值提取网页信息
def analysis_one_page(response, url):
    '''
    :param response: 网页的返回值
    :param url: 网页的url
    :return:
    '''
    propertyDict = {}  # 人物属性字典
    contain_name_url_set = set()  # 本页面包含的(姓名-链接)集合
    rel_set = set()  # 关系集合（元素是三元组）

    html = response.content.decode('utf-8')
    # 处理属性字典
    propertyDict = get_property(html, propertyDict)  # 属性名字典
    propertyDict['numID'] = url  # url
    propertyDict['strID'] = get_name_wiki(html)  # 词条名称
    propertyDict['abstract'] = get_abstract(html)  # 摘要字符串
    fix_property_dict = alignProperty(propertyDict, set_tag='baidubaike')  # 属性对齐

    main_name = propertyDict['strID'].split('（')[0]  # 本词条的广义名称

    contain_name_url_set = get_href_wiki(html, contain_name_url_set)  # 内链字典
    contain_name_url_set = get_tongyi(html, contain_name_url_set, main_name)  # 同义词的广义名称与本词条相同
    contain_name_url_set, rel_set = get_rel(html, url, contain_name_url_set, rel_set)  # 获取关系
    return fix_property_dict, contain_name_url_set, rel_set
