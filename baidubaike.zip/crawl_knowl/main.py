import public

if __name__ == '__main__':
    # batch_url = ["https://baike.baidu.com/item/%E6%95%B0%E5%AD%A6/107037",
    #              "https://baike.baidu.com/item/%E7%89%A9%E7%90%86%E5%AD%A6/313183"]
    batch_url = [
        "https://zh.wikipedia.org/wiki/Wikipedia:%E5%88%86%E9%A1%9E%E7%B4%A2%E5%BC%95"
    ]
    all_node = []
    all_rel = []
    for i in range(2):
        # 保存本次爬取节点和三元组，并赋值下次爬取列表
        batch_node, batch_rel, inter_batch = public.ana_batch(batch_url)

        batch_url = inter_batch[1:100]

        all_node.extend(batch_node)
        all_rel.extend(batch_rel)
        print("第" + str(i) + "次爬取")
